package com.timestop.proxy;

import com.timestop.client.ClientEventHandler;
import com.timestop.client.ClientKeyBindings;
import com.timestop.item.ModItems;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ClientProxy extends CommonProxy {
    @Override
    public void registerModels() {
        // Item models MUST be registered in response to ModelRegistryEvent, not just
        // called directly from some arbitrary point in the mod lifecycle (init() was
        // too late here) - this is what actually determines the texture, and getting
        // the timing wrong is exactly what produces the purple/black "missing texture"
        // checkerboard even though the item itself loads fine.
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onModelRegistry(ModelRegistryEvent event) {
        ModItems.registerModels();
    }

    @Override
    public void clientInit() {
        ClientKeyBindings.register();
        MinecraftForge.EVENT_BUS.register(new ClientEventHandler());
    }
}
